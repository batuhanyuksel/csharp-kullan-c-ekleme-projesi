﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KullaniciProjesi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Show User butonuna tıklandığında çalışacak fonksiyon
        private void SaveUserButtonClickListener(object sender, EventArgs e)
        {
            // UserRegistiration sınıfımızdan bir obje oluşturuyoruz.
            UserRegistration userRegistration = new UserRegistration(usernameTextBox.Text, emailTextBox.Text, passwordTextBox.Text); // Değerleri textBox lardan alıyoruz
            
            int value = userDataGridView.Rows.Add(1); // Butona her basıldığnuda tabloya bir row yani satır ekliyor
            
            // Eklenen satırlara veriler getter lar aracılığı ile getirilerek atanıyor.
            userDataGridView.Rows[value].Cells[0].Value = userRegistration.GetUsername(); 
            userDataGridView.Rows[value].Cells[1].Value = userRegistration.GetPassword();
            userDataGridView.Rows[value].Cells[2].Value = userRegistration.GetEmail();
        }
    }
}