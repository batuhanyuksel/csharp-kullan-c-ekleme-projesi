﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KullaniciProjesi
{
    class UserRegistration
    {
        private string username; private string email; private string password; // Kullanıcı bilgisinin tutulduğu private değişkenler

        public UserRegistration(string username, string email, string password) // Consturactor
        {
            this.username = username; this.password = password; // Veriler parametre olarak gönderilen verilere eşitleniyor.
            this.email = email;
        }

        // Getter ve Setter methodlar
        public string GetPassword() { return this.password; }

        public string GetUsername() { return this.username; }

        public string GetEmail() { return this.email; }

        public void SetPassword(string password) { this.password = password; }

        public void SetUsername(string username) { this.username = username; }

        public void SetEmail(string email) { this.email = email; }
    }
}
